/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_466(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_289(unsigned x)
{
    return x + 2425379042U;
}

void setval_339(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_332(unsigned x)
{
    return x + 3284633672U;
}

unsigned getval_248()
{
    return 1479052461U;
}

void setval_116(unsigned *p)
{
    *p = 3251079496U;
}

unsigned addval_105(unsigned x)
{
    return x + 1358170623U;
}

void setval_100(unsigned *p)
{
    *p = 3281162328U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_163()
{
    return 3677933963U;
}

void setval_176(unsigned *p)
{
    *p = 2429659546U;
}

unsigned getval_362()
{
    return 3234120329U;
}

unsigned addval_382(unsigned x)
{
    return x + 3229142665U;
}

unsigned addval_299(unsigned x)
{
    return x + 3284306362U;
}

unsigned addval_441(unsigned x)
{
    return x + 3766569016U;
}

unsigned getval_306()
{
    return 3281047209U;
}

unsigned addval_177(unsigned x)
{
    return x + 2425409929U;
}

unsigned addval_132(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_420()
{
    return 2429454764U;
}

unsigned getval_454()
{
    return 2496760140U;
}

unsigned addval_371(unsigned x)
{
    return x + 3223372417U;
}

unsigned addval_187(unsigned x)
{
    return x + 3529556617U;
}

unsigned getval_264()
{
    return 2464188744U;
}

unsigned addval_389(unsigned x)
{
    return x + 2227425675U;
}

unsigned getval_207()
{
    return 3223375561U;
}

unsigned getval_243()
{
    return 3353381192U;
}

void setval_351(unsigned *p)
{
    *p = 3525365449U;
}

unsigned getval_450()
{
    return 3286272328U;
}

void setval_265(unsigned *p)
{
    *p = 3372797576U;
}

void setval_384(unsigned *p)
{
    *p = 3682910857U;
}

unsigned addval_206(unsigned x)
{
    return x + 3281179017U;
}

unsigned getval_262()
{
    return 3269495112U;
}

void setval_367(unsigned *p)
{
    *p = 3230978441U;
}

unsigned getval_449()
{
    return 3375943305U;
}

unsigned addval_331(unsigned x)
{
    return x + 3372797581U;
}

unsigned getval_101()
{
    return 3375944073U;
}

unsigned addval_158(unsigned x)
{
    return x + 3229926027U;
}

void setval_127(unsigned *p)
{
    *p = 3676357273U;
}

unsigned addval_333(unsigned x)
{
    return x + 3766569023U;
}

unsigned getval_107()
{
    return 3224945281U;
}

void setval_272(unsigned *p)
{
    *p = 2430634312U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
